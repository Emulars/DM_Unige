package com.example;

public enum BRANDS {
    CaramelSprinkle,
    EnergyMax,
    SoulWater,
    InFuse;
}
