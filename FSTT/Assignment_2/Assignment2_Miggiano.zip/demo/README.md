Davide Miggiano - 4840761

I recreated the Maven project from scratch, importing the classes, interfaces etc from the repository.
Then I wrote the different test cases and ran the procedure to display the code coverage but unfortunately the latter does not update.